# Start mock checkout API on port 8766 (optional)
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root
if (Test-Path "..\.venv\Scripts\Activate.ps1") {
    & "..\.venv\Scripts\Activate.ps1"
} elseif (Test-Path "..\..\backend\.venv\Scripts\Activate.ps1") {
    & "..\..\backend\.venv\Scripts\Activate.ps1"
}
pip install -q -r requirements.txt
Write-Host "Mock API: http://127.0.0.1:8766/health" -ForegroundColor Cyan
uvicorn main:app --reload --host 127.0.0.1 --port 8766
