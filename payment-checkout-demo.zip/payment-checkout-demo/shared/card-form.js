(function (global) {
  function digitsOnly(value) {
    return (value || "").replace(/\D/g, "");
  }

  function validateExpiry(expMonth, expYear) {
    if (!expMonth || !expYear) return false;
    var mm = expMonth.value;
    var yy = expYear.value;
    if (mm.length !== 2 || yy.length !== 2) return false;
    var m = parseInt(mm, 10);
    return m >= 1 && m <= 12;
  }

  function initCardForm(form) {
    if (!form) return { validate: function () { return true; } };

    var cardInput = form.querySelector("[data-card-number]");
    var expMonth = form.querySelector("[data-exp-month]");
    var expYear = form.querySelector("[data-exp-year]");
    var cvcInput = form.querySelector("[data-cvc]");

    if (cardInput) {
      cardInput.addEventListener("input", function () {
        var d = digitsOnly(cardInput.value).slice(0, 16);
        cardInput.value = d.replace(/(\d{4})(?=\d)/g, "$1 ").trim();
      });
    }

    if (expMonth) {
      expMonth.addEventListener("input", function () {
        var d = digitsOnly(expMonth.value).slice(0, 2);
        if (d.length === 1 && parseInt(d, 10) > 1) d = "0" + d;
        if (d.length === 2) {
          var m = parseInt(d, 10);
          if (m < 1) d = "01";
          if (m > 12) d = "12";
        }
        expMonth.value = d;
        if (d.length === 2 && expYear) expYear.focus();
      });
    }

    if (expYear) {
      expYear.addEventListener("input", function () {
        expYear.value = digitsOnly(expYear.value).slice(0, 2);
      });
    }

    if (cvcInput) {
      cvcInput.addEventListener("input", function () {
        cvcInput.value = digitsOnly(cvcInput.value).slice(0, 4);
      });
    }

    return {
      validate: function () {
        if (!validateExpiry(expMonth, expYear)) {
          if (expMonth && expMonth.value.length !== 2) expMonth.focus();
          else if (expYear) expYear.focus();
          return false;
        }
        return true;
      }
    };
  }

  global.HeeriseCardForm = { init: initCardForm };
})(window);
