# Career Lab → Checkout Demo 对接（可选）

演示代码 **全部** 在 `payment-checkout-demo/` 内。若要从 Career Lab Pricing 跳入本地演示，**只允许** 做下列 **router / URL 导向** 级别的改动，且需团队自行决定是否在本地启用。

## 方案 A — 仅本地手动打开（当前默认）

不修改主仓库任何文件。开发者在浏览器直接访问：

```
http://127.0.0.1:8765/select-method/?product_id=bootcamp-premium&amount=149900&currency=USD
```

## 方案 B — Hugo 参数 + 单点链接（最小改动）

**仅改 1 处配置**（`hugo.toml`）：

```toml
[params.payment_demo]
  enabled = true
  base_url = "http://127.0.0.1:8765"
```

**仅改 Pricing 按钮 `href` 模板 1 行**（`career-lab-pricing.html`）— 将 `APPLY NOW` / project card 在 `enabled` 时指向：

```
{{ .Site.Params.payment_demo.base_url }}/select-method/?product_id=...&amount=...
```

> 生产环境 `enabled = false`，按钮仍走原有 bootcamp modal / payment URL。

## 方案 C — FastAPI 静态挂载（本地 backend router）

**仅改** `backend/app/main.py` 增加 **development-only** 路由（勿用于生产）：

```python
# if settings.checkout_demo_mount:
#     app.mount("/checkout-demo", StaticFiles(...), name="checkout-demo")
```

静态文件仍来自 `payment-checkout-demo/`，不在 backend 内复制代码。

---

**禁止：** 把 demo CSS/JS/HTML 复制进 `frontend/hugo-landing/`；禁止把 mock API 合并进生产 `backend/app/routers/`。
