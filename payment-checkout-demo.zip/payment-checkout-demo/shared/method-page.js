(function (global) {
  function initMethodPage(opts) {
    var ctx = global.HeeriseCheckoutDemo.readContext();
    var q = global.HeeriseCheckoutDemo.buildQuery(ctx);
    var back = document.getElementById("back-link");
    if (back) back.href = global.HeeriseCheckoutDemo.demoUrl("/select-method/") + "?" + q;

    var aside = document.getElementById("order-summary");
    if (aside) {
      aside.innerHTML =
        '<h2 style="margin:0 0 16px;font-size:16px;color:#011f5b;">Order Summary</h2>' +
        '<div class="summary-row"><span>Order</span><strong data-order-id></strong></div>' +
        '<div class="summary-row"><span>Product</span><strong data-product-name></strong></div>' +
        '<div class="summary-total"><span>Total</span><span data-amount></span></div>';
      global.HeeriseCheckoutDemo.hydrateSummary(aside, ctx);
    }

    function runPay(methodId, btn) {
      if (btn) {
        btn.disabled = true;
        btn.textContent = "Processing…";
      }
      return global.HeeriseCheckoutMock.pay(methodId, ctx).then(function (r) {
        global.HeeriseCheckoutMock.goResult(r, ctx, methodId);
      });
    }

    if (opts.onReady) opts.onReady({ ctx: ctx, runPay: runPay });
  }

  global.HeeriseMethodPage = { init: initMethodPage };
})(window);
