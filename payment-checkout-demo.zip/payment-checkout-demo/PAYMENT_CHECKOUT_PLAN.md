# Career Lab 付款流程演示 — 总体方案 v0.2

> **状态：** P0 静态演示 **已实现**（`payment-checkout-demo/`）  
> **约束：** 演示前后端 **仅在本目录**；主仓库 `frontend/`、`backend/` **不修改**（可选 router 见 `INTEGRATION.md`）  
> **版本：** v0.2 · 2026-06

---

## 1. 变更说明（v0.2）

### 1.1 保留的 Payment Method（10 种）

| 原编号 | Method ID | 展示名 | 演示路由 | 演示结果 |
|--------|-----------|--------|----------|----------|
| 1 | `card` | Credit / Debit Card | `/methods/card/` | success |
| 2 | `paypal` | PayPal | `/methods/paypal/` | success |
| 4 | `google_pay` | Google Pay | `/methods/google-pay/` | success |
| 5 | `apple_pay` | Apple Pay | `/methods/apple-pay/` | success |
| 8 | `ach` | ACH Bank Debit | `/methods/ach/` | **pending** |
| 10 | `venmo` | Venmo | `/methods/venmo/` | success |
| 11 | `samsung_pay` | Samsung Pay | `/methods/samsung-pay/` | success |
| 13 | `link` | Stripe Link | `/methods/link/` | success |
| — | `alipay` | Alipay 支付宝 | `/methods/alipay/` | **pending** |
| — | `wechat_pay` | WeChat Pay 微信支付 | `/methods/wechat-pay/` | **pending** |

### 1.2 已移除（本演示不包含）

Zelle、Wire、Klarna/Affirm、Crypto、SEPA、Cash 等。

### 1.3 已实现文件树

```
payment-checkout-demo/
├── index.html
├── select-method/index.html
├── methods/{card,paypal,google-pay,apple-pay,ach,venmo,samsung-pay,link,alipay,wechat-pay}/index.html
├── result/{success,pending,failed}.html
├── shared/{styles.css,checkout-context.js,mock-api.js,method-page.js}
├── backend/{main.py,requirements.txt,serve-api.ps1}
├── serve.ps1
├── README.md
├── INTEGRATION.md
└── PAYMENT_CHECKOUT_PLAN.md
```

---

## 2. 用户流程

```
Career Lab Pricing（未来可选跳转）
        ↓
select-method/          选择 Payment Method（10 选 1）
        ↓
methods/{method}/       各渠道 Checkout UI
        ↓
result/success|pending|failed.html
```

**Checkout Context（Query）：** `product_id`, `product_name`, `amount`（cents）, `currency`, `order_id`, `return_url`, `email`

---

## 3. 各支付方式 — API / 数据 / 入账

> 生产集成参考；**当前演示** 为前端 mock + 可选 `POST /api/demo/pay`。

### 3.1 Credit / Debit Card

| 项 | 内容 |
|----|------|
| API | ✅ Stripe **Payment Intents** / PayPal Advanced Card |
| 所需数据 | `amount`, `currency`, `metadata.order_id`, `client_secret`（前端 confirm） |
| 入账 | Stripe balance → **Payout** → US business bank（T+2 典型） |
| 演示 | 卡号 `4242…` 表单 → mock success |

### 3.2 PayPal

| 项 | 内容 |
|----|------|
| API | ✅ **Orders API v2** → `capture` |
| 所需数据 | `purchase_units[].amount`, `reference_id`, `return_url` |
| Webhook | `PAYMENT.CAPTURE.COMPLETED` |
| 入账 | PayPal balance → bank transfer |
| 演示 | 「Continue with PayPal」按钮 |

### 3.3 Google Pay

| 项 | 内容 |
|----|------|
| API | ✅ Stripe **Payment Request** / Google Pay API（token → card rail） |
| 所需数据 | PaymentIntent + domain verification |
| 入账 | 同 Card（经 Stripe） |
| 演示 | Google Pay 按钮 mock |

### 3.4 Apple Pay

| 项 | 内容 |
|----|------|
| API | ✅ **Apple Pay on the Web** + Stripe |
| 所需数据 | Merchant ID、domain association、`client_secret` |
| 入账 | 同 Card |
| 演示 | Apple Pay 按钮 mock |

### 3.5 ACH Bank Debit

| 项 | 内容 |
|----|------|
| API | ✅ Stripe `us_bank_account` / Financial Connections |
| 所需数据 | bank account token, `PaymentIntent` |
| 入账 | Stripe → bank（**3–5 工作日** final） |
| 演示 | 银行账户表单 → **pending** |

### 3.6 Venmo

| 项 | 内容 |
|----|------|
| API | ✅ **PayPal Commerce**（`payment_source: venmo`，美国 USD） |
| 所需数据 | 同 PayPal Order |
| 入账 | PayPal → bank |
| 演示 | Venmo 按钮 mock |

### 3.7 Samsung Pay

| 项 | 内容 |
|----|------|
| API | ✅ Samsung Pay SDK / Stripe wallet token |
| 所需数据 | 同 wallet tokenization |
| 入账 | 同 Card |
| 演示 | Samsung Pay 按钮 mock |

### 3.8 Stripe Link

| 项 | 内容 |
|----|------|
| API | ✅ Stripe **Link**（Payment Element） |
| 所需数据 | customer email, saved PM |
| 入账 | 同 Card |
| 演示 | 邮箱 + Link 按钮 |

### 3.9 Alipay 支付宝

| 项 | 内容 |
|----|------|
| API | ✅ Alipay+ / Antom **Create Payment Session**；或 Stripe `alipay`（区域限制） |
| 所需数据 | `out_trade_no`, `total_amount`, `subject`, `notify_url`, 签名 |
| Webhook | 异步 notify（验签） |
| 入账 | 支付宝商户 → 跨境/境内结算账户 |
| 演示 | QR 占位 +「我已完成支付」→ **pending** |

### 3.10 WeChat Pay 微信支付

| 项 | 内容 |
|----|------|
| API | ✅ **API v3** Native / JSAPI / H5 |
| 所需数据 | `appid`, `mchid`, `out_trade_no`, `amount`, `notify_url` |
| 入账 | 微信商户平台 → 对公/跨境账户 |
| 演示 | QR 占位 +「我已完成支付」→ **pending** |

---

## 4. 推荐生产架构

```
Career Lab → Backend POST /checkout/sessions
                 ├─ Stripe（card, gpay, apple, ach, link, samsung）
                 ├─ PayPal（paypal, venmo）
                 └─ Alipay / WeChat（跨境进件或 Airwalix 等）
                         ↓
                 Business bank account
```

**MVP 建议：** Stripe + PayPal 覆盖 1/2/4/5/8/10/11/13；Alipay/WeChat 作为华人用户 Phase 2。

---

## 5. Mock Backend（本目录 optional）

| Endpoint | 说明 |
|----------|------|
| `GET /health` | 健康检查 |
| `POST /api/demo/pay` | `{ method, order_id, amount, currency }` → success / pending |

启动：`backend/serve-api.ps1` → `http://127.0.0.1:8766`

---

## 6. 本地启动

```powershell
cd payment-checkout-demo
.\serve.ps1
# → http://127.0.0.1:8765/select-method/
```

---

## 7. 与主站集成（仅 router，可选）

见 [INTEGRATION.md](./INTEGRATION.md)。**默认不修改** `frontend/`、`backend/` 生产代码。

---

## 8. 后续 Phase

| Phase | 内容 |
|-------|------|
| P0 ✅ | 本目录静态演示 10 种方式 |
| P1 | Stripe test mode 接入（仍限 demo 目录或 feature flag） |
| P2 | PayPal sandbox |
| P3 | Career Lab 单点 URL 跳转（router only） |
| P4 | 生产 Checkout + Webhook 写入主 backend |

---

## 9. 官方文档

- Stripe: https://docs.stripe.com/payments/payment-intents  
- PayPal Orders: https://developer.paypal.com/docs/api/orders/v2/  
- Apple Pay Web: https://developer.apple.com/documentation/apple_pay_on_the_web  
- Google Pay: https://developers.google.com/pay/api/web  
- WeChat Pay v3: https://pay.weixin.qq.com/wiki/doc/apiv3/index.shtml  
- Alipay+: https://docs.antom.com/
