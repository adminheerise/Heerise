# Start static checkout demo on port 8765
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Root
Write-Host "Checkout demo: http://127.0.0.1:8765/select-method/" -ForegroundColor Cyan
Write-Host "Example with order context:" -ForegroundColor DarkGray
Write-Host "http://127.0.0.1:8765/select-method/?product_id=bootcamp-premium&amount=149900&currency=USD&product_name=Career+Lab+Premium" -ForegroundColor DarkGray
python -m http.server 8765 --bind 127.0.0.1
