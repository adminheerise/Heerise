(function (global) {
  function readContext() {
    var params = new URLSearchParams(window.location.search);
    var amountRaw = params.get("amount") || "149900";
    var amount = parseInt(amountRaw, 10);
    if (isNaN(amount)) amount = 149900;
    return {
      product_id: params.get("product_id") || "bootcamp-premium",
      product_name: params.get("product_name") || "Career Lab Bootcamp — Premium Tier",
      amount: amount,
      currency: (params.get("currency") || "USD").toUpperCase(),
      billing_period: params.get("billing_period") || "one_time",
      return_url: params.get("return_url") || "/career-lab/",
      customer_email: params.get("email") || "",
      order_id: params.get("order_id") || "ORD-" + Date.now().toString(36).toUpperCase()
    };
  }

  function formatMoney(cents, currency) {
    var cur = currency || "USD";
    try {
      return new Intl.NumberFormat("en-US", { style: "currency", currency: cur }).format(cents / 100);
    } catch (e) {
      return "$" + (cents / 100).toFixed(2);
    }
  }

  function buildQuery(ctx, extra) {
    var p = new URLSearchParams();
    p.set("product_id", ctx.product_id);
    p.set("product_name", ctx.product_name);
    p.set("amount", String(ctx.amount));
    p.set("currency", ctx.currency);
    p.set("billing_period", ctx.billing_period);
    p.set("return_url", ctx.return_url);
    p.set("order_id", ctx.order_id);
    if (ctx.customer_email) p.set("email", ctx.customer_email);
    if (extra) {
      Object.keys(extra).forEach(function (k) {
        p.set(k, extra[k]);
      });
    }
    return p.toString();
  }

  function getDemoBase() {
    var path = window.location.pathname.replace(/\\/g, "/");
    path = path.replace(/\/index\.html$/i, "");
    if (/\.html$/i.test(path)) {
      path = path.replace(/\/[^/]+$/, "");
    }
    var re = /^(\/.*)?(?=\/(?:methods|select-method|result|shared|backend)(?:\/|$))/;
    var m = path.match(re);
    if (m) return m[1] || "";
    if (path === "" || path === "/") return "";
    return path.replace(/\/[^/]+$/, "") || "";
  }

  function demoUrl(subpath) {
    var base = getDemoBase();
    if (!subpath) return base || "/";
    if (subpath.charAt(0) !== "/") subpath = "/" + subpath;
    return (base || "") + subpath;
  }

  function hydrateSummary(root, ctx) {
    if (!root) return;
    var money = formatMoney(ctx.amount, ctx.currency);
    root.querySelectorAll("[data-order-id]").forEach(function (el) {
      el.textContent = ctx.order_id;
    });
    root.querySelectorAll("[data-product-name]").forEach(function (el) {
      el.textContent = ctx.product_name;
    });
    root.querySelectorAll("[data-amount]").forEach(function (el) {
      el.textContent = money;
    });
  }

  global.HeeriseCheckoutDemo = {
    readContext: readContext,
    formatMoney: formatMoney,
    buildQuery: buildQuery,
    hydrateSummary: hydrateSummary,
    getDemoBase: getDemoBase,
    demoUrl: demoUrl
  };
})(window);
