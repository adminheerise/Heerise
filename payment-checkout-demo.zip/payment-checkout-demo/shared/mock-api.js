(function (global) {
  var PENDING_METHODS = { ach: true, alipay: true, wechat_pay: true };
  var DELAY_MS = 1400;

  function pay(methodId, ctx) {
    return new Promise(function (resolve) {
      setTimeout(function () {
        var pending = !!PENDING_METHODS[methodId];
        resolve({
          ok: !pending,
          status: pending ? "pending" : "success",
          method: methodId,
          order_id: ctx.order_id,
          transaction_id: "TXN-DEMO-" + Math.random().toString(36).slice(2, 10).toUpperCase()
        });
      }, DELAY_MS);
    });
  }

  function goResult(result, ctx, methodId) {
    var q = global.HeeriseCheckoutDemo.buildQuery(ctx, {
      method: methodId || "",
      txn: result.transaction_id || ""
    });
    var url = global.HeeriseCheckoutDemo.demoUrl("/result/" + result.status + ".html");
    window.location.href = url + "?" + q;
  }

  global.HeeriseCheckoutMock = {
    pay: pay,
    goResult: goResult
  };
})(window);
