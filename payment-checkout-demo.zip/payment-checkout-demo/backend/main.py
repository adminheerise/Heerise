"""Local mock checkout API — lives only under payment-checkout-demo/."""
from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

app = FastAPI(title="Heerise Checkout Demo API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

PENDING = {"ach", "alipay", "wechat_pay"}


class PayRequest(BaseModel):
    method: str
    order_id: str
    amount: int = Field(ge=0)
    currency: str = "USD"


class PayResponse(BaseModel):
    ok: bool
    status: str
    method: str
    order_id: str
    transaction_id: str


@app.get("/health")
def health():
    return {"status": "ok", "scope": "payment-checkout-demo"}


@app.post("/api/demo/pay", response_model=PayResponse)
def demo_pay(body: PayRequest):
    pending = body.method in PENDING
    txn = f"TXN-API-{body.order_id[-6:]}"
    return PayResponse(
        ok=not pending,
        status="pending" if pending else "success",
        method=body.method,
        order_id=body.order_id,
        transaction_id=txn,
    )
