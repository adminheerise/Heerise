# Payment Checkout Demo / 付款页面演示

**本地专用** · 已加入 `.gitignore` · 不推送远程

## 快速启动

```powershell
cd D:\heerise\payment-checkout-demo
.\serve.ps1
```

浏览器打开：

```
http://127.0.0.1:8765/select-method/?product_id=bootcamp-premium&amount=149900&currency=USD&product_name=Career+Lab+Premium
```

可选 mock API（FastAPI，仅本目录）：

```powershell
cd D:\heerise\payment-checkout-demo\backend
.\serve-api.ps1
```

## 演示范围（10 种 Payment Method）

| # | Method | 路径 |
|---|--------|------|
| 1 | Credit / Debit Card | `/methods/card/` |
| 2 | PayPal | `/methods/paypal/` |
| 4 | Google Pay | `/methods/google-pay/` |
| 5 | Apple Pay | `/methods/apple-pay/` |
| 8 | ACH Bank Debit | `/methods/ach/` → **pending** |
| 10 | Venmo | `/methods/venmo/` |
| 11 | Samsung Pay | `/methods/samsung-pay/` |
| 13 | Stripe Link | `/methods/link/` |
| — | Alipay 支付宝 | `/methods/alipay/` → **pending** |
| — | WeChat Pay 微信 | `/methods/wechat-pay/` → **pending** |

**已移除：** Zelle、Wire、BNPL、Crypto 等（见方案文档 v0.2）

## 文档

- [PAYMENT_CHECKOUT_PLAN.md](./PAYMENT_CHECKOUT_PLAN.md) — 完整方案（API / 入账 / 合规）
- [INTEGRATION.md](./INTEGRATION.md) — 与 Career Lab 的最小 router 对接说明（可选）

## 目录结构

```
payment-checkout-demo/
├── index.html
├── select-method/
├── methods/{card,paypal,...}/
├── result/{success,pending,failed}.html
├── shared/
├── backend/          # 可选 mock API
├── serve.ps1
└── PAYMENT_CHECKOUT_PLAN.md
```

**约束：** 演示前后端代码 **仅在本文件夹**；主仓库 `frontend/`、`backend/` 生产代码不在此演示阶段修改。
