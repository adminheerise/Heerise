(function (global) {
  /**
   * Integration reference for each payment method (demo / production planning).
   * userInput: fields the payer enters in UI or wallet
   * merchantProvides: server-side secrets, order data, callbacks we configure
   */
  var METHODS = [
    {
      id: "card",
      href: "/methods/card/",
      icon: "CARD",
      cls: "card",
      title: "Credit / Debit Card",
      titleZh: "信用卡 / 借记卡",
      desc: "Visa, Mastercard, Amex — via Stripe Payment Intents",
      api: "Stripe Payment Intents (+ optional PayPal Advanced Card Processing)",
      userInput: [
        "Card number, expiry (MM/YY), CVC",
        "Cardholder name (often required for AVS)",
        "Billing postal code / country (US/EU fraud checks)",
        "3-D Secure step-up when issuer requires (OTP / bank app)"
      ],
      merchantProvides: [
        "Stripe secret key (server) + publishable key (browser)",
        "amount, currency, metadata.order_id on PaymentIntent",
        "client_secret returned to frontend for confirm",
        "Webhook endpoint + signing secret (payment_intent.succeeded / failed)",
        "Statement descriptor, MCC, business verification for live mode"
      ],
      integration: [
        "Backend: POST /v1/payment_intents { amount, currency, metadata }",
        "Frontend: Stripe.js → Elements or confirmCardPayment(client_secret)",
        "User submits card → Stripe tokenizes (PCI scope reduced)",
        "Backend listens to webhook; mark order paid only after succeeded event"
      ],
      international: [
        "Cards work cross-border; settlement currency may differ from charge currency (FX + ~1–3% spread typical).",
        "Strong Customer Authentication (SCA) required in EEA/UK — expect 3DS redirects.",
        "US-issued cards on USD checkout are simplest MVP; multi-currency display needs FX rules and local tax.",
        "Disputes/chargebacks: evidence in English; international cards may have longer dispute windows."
      ],
      docs: "https://docs.stripe.com/payments/payment-intents"
    },
    {
      id: "paypal",
      href: "/methods/paypal/",
      icon: "PP",
      cls: "paypal",
      title: "PayPal",
      titleZh: "PayPal",
      desc: "Redirect to PayPal to approve; capture on return",
      api: "PayPal Checkout Orders API v2 (create → approve → capture)",
      userInput: [
        "PayPal login (email/phone + password) or PayPal guest card",
        "Approval of purchase amount and shipping (if shown)",
        "Optional: PayPal balance vs linked bank/card choice"
      ],
      merchantProvides: [
        "PayPal REST client_id (browser) + client_secret (server only)",
        "purchase_units[].amount { currency_code, value }, reference_id / custom_id = order_id",
        "return_url, cancel_url after order create",
        "Webhook: PAYMENT.CAPTURE.COMPLETED, PAYMENT.Capture.DENIED, etc.",
        "Sandbox vs Live base URL switch"
      ],
      integration: [
        "Backend: POST /v2/checkout/orders with intent CAPTURE",
        "Frontend: redirect to approval link (or PayPal JS SDK buttons)",
        "User approves on paypal.com → redirect back with token",
        "Backend: POST /v2/checkout/orders/{id}/capture → verify webhook before fulfillment"
      ],
      international: [
        "PayPal supports many countries/currencies; buyer FX conversion may apply.",
        "US merchant + USD is standard for Career Lab MVP; cross-border fees vary by corridor.",
        "Some regions restrict certain funding sources; always show currency clearly before redirect.",
        "Refunds go back to PayPal balance/funding source; partial refunds supported via API."
      ],
      docs: "https://developer.paypal.com/docs/api/orders/v2/"
    },
    {
      id: "google_pay",
      href: "/methods/google-pay/",
      icon: "G",
      cls: "wallet",
      title: "Google Pay",
      titleZh: "Google Pay",
      desc: "Wallet token → card rail (usually Stripe Payment Request)",
      api: "Google Pay API + Stripe Payment Request / Payment Intents",
      userInput: [
        "Google account + device unlock (minimal fields shown)",
        "Shipping/contact only if requested in paymentDataRequest",
        "Underlying card already vaulted in Google Pay — user does not re-type PAN"
      ],
      merchantProvides: [
        "Google Pay merchantId (PRODUCTION/TEST) + gateway merchant ID (e.g. Stripe)",
        "PaymentIntent with amount/currency; domain verified in Search Console",
        "allowedPaymentMethods, merchantInfo, transactionInfo in JS",
        "Stripe publishable key; webhook same as card"
      ],
      integration: [
        "Load Google Pay JS; check canMakePayment()",
        "User taps Google Pay → paymentData.paymentMethodData.tokenizationData",
        "Pass token to Stripe confirmCardPayment or create PM + confirm PI",
        "Treat as card payment for settlement; webhook payment_intent.succeeded"
      ],
      international: [
        "Availability depends on user's country, device, and issuer — not all cards support tokenization.",
        "Display currency must match PaymentIntent; Google may show buyer-local currency estimate.",
        "Chrome/Android primary; Safari/iOS users often use Apple Pay instead.",
        "Same cross-border card rules as direct card once tokenized."
      ],
      docs: "https://developers.google.com/pay/api/web"
    },
    {
      id: "apple_pay",
      href: "/methods/apple-pay/",
      icon: "",
      cls: "wallet",
      title: "Apple Pay",
      titleZh: "Apple Pay",
      desc: "Apple Pay on the Web via Stripe or direct merchant ID",
      api: "Apple Pay on the Web + Stripe Payment Request",
      userInput: [
        "Face ID / Touch ID / device passcode",
        "Billing contact (sometimes auto-filled from Wallet)",
        "No manual card entry when card already in Wallet"
      ],
      merchantProvides: [
        "Apple Merchant ID + Payment Processing Certificate",
        "Domain verification file hosted at /.well-known/apple-developer-merchantid-domain-association",
        "Stripe Apple Pay domain registration or direct session validation",
        "PaymentIntent + client_secret; HTTPS required"
      ],
      integration: [
        "Safari: ApplePaySession.canMakePayments / begin",
        "Validate merchant (Stripe handles if using their integration)",
        "On paymentauthorized → confirm Stripe PI with Apple Pay token",
        "Webhook confirms success; enable only on supported Apple devices/browsers"
      ],
      international: [
        "Apple Pay country list differs by issuer; US Wallet cards on USD checkout is typical MVP.",
        "Cross-border: issuer may decline or require additional authentication.",
        "Not available in all browsers (Safari primary on macOS/iOS).",
        "Regulatory: display merchant name as registered with Apple."
      ],
      docs: "https://developer.apple.com/documentation/apple_pay_on_the_web"
    },
    {
      id: "ach",
      href: "/methods/ach/",
      icon: "ACH",
      cls: "ach",
      title: "ACH Bank Debit",
      titleZh: "ACH 银行借记",
      desc: "US bank account debit — settlement in 3–5 business days",
      api: "Stripe ACH Direct Debit (us_bank_account) + Financial Connections",
      userInput: [
        "Bank login via Financial Connections OR manual routing + account numbers",
        "Account holder name, account type (checking/savings)",
        "Micro-deposit verification if not instant-verified",
        "Authorization mandate text acceptance (NACHA compliance)"
      ],
      merchantProvides: [
        "PaymentIntent with payment_method_types: [us_bank_account]",
        "Customer object (recommended) + mandate acceptance timestamp/IP",
        "Webhook: payment_intent.processing → succeeded (delayed) or failed",
        "US business entity; ACH only for USD US bank accounts"
      ],
      integration: [
        "Backend creates PI + Customer",
        "Frontend: Stripe Financial Connections or collect bank details",
        "confirmUsBankAccountPayment → status processing",
        "Fulfill only on payment_intent.succeeded (not on submit); expect pending state days"
      ],
      international: [
        "US-only rail — not for overseas bank accounts (use SEPA elsewhere, not in this demo).",
        "Lower fees than cards but slow settlement and return risk (NSF, disputes up to 60 days).",
        "Not suitable for instant digital access unless you grant provisional access with clawback policy.",
        "Cross-border buyers with only non-US banks cannot use ACH."
      ],
      docs: "https://docs.stripe.com/payments/ach-direct-debit"
    },
    {
      id: "venmo",
      href: "/methods/venmo/",
      icon: "V",
      cls: "venmo",
      title: "Venmo",
      titleZh: "Venmo",
      desc: "US social wallet via PayPal Commerce Platform",
      api: "PayPal Orders v2 with payment_source: { venmo: {} }",
      userInput: [
        "Venmo app login / approval on mobile",
        "Amount confirmation inside Venmo",
        "Typically mobile-first; desktop may QR or deep link"
      ],
      merchantProvides: [
        "PayPal merchant account with Venmo enabled (US, USD)",
        "Same Orders API as PayPal with venmo payment_source",
        "return_url / cancel_url; Venmo-specific branding guidelines",
        "Webhooks same family as PayPal captures"
      ],
      integration: [
        "Create PayPal order with venmo as funding source",
        "Redirect or Venmo button → user approves in Venmo app",
        "Capture on return; verify PAYMENT.CAPTURE.COMPLETED webhook",
        "Fallback to PayPal if Venmo unavailable on device"
      ],
      international: [
        "Venmo is US-only; buyers outside US cannot pay with Venmo.",
        "USD only; not a cross-border wallet like PayPal globally.",
        "Popular with US Gen-Z — good optional rail, not primary for international cohort.",
        "Marketing/compliance: cannot imply peer-to-peer; must show merchant name."
      ],
      docs: "https://developer.paypal.com/docs/checkout/pay-with-venmo/"
    },
    {
      id: "samsung_pay",
      href: "/methods/samsung-pay/",
      icon: "S",
      cls: "wallet",
      title: "Samsung Pay",
      titleZh: "Samsung Pay",
      desc: "Samsung wallet tokenization — often via Stripe wallet",
      api: "Samsung Pay Web / Stripe wallet payment method",
      userInput: [
        "Samsung Pay PIN / biometrics on supported Samsung devices",
        "Card already enrolled in Samsung Wallet",
        "Minimal checkout fields"
      ],
      merchantProvides: [
        "Samsung Pay merchant registration (serviceId) if direct integration",
        "Or Stripe Payment Request with wallet enabled",
        "PaymentIntent, domain, HTTPS",
        "Device/browser compatibility checks"
      ],
      integration: [
        "Detect Samsung Internet + Samsung Pay availability",
        "Request payment token from Samsung Pay SDK",
        "Submit token to PSP (Stripe) to confirm PaymentIntent",
        "Same webhook flow as card"
      ],
      international: [
        "Strongest in Samsung-heavy markets (KR, US, parts of EU); not universal on all Android.",
        "Tokenized card inherits issuer cross-border and FX rules.",
        "Lower priority unless analytics show Samsung Pay usage.",
        "Keep Google Pay as primary Android wallet for broader reach."
      ],
      docs: "https://developer.samsung.com/pay/web"
    },
    {
      id: "link",
      href: "/methods/link/",
      icon: "Link",
      cls: "wallet",
      title: "Stripe Link",
      titleZh: "Stripe Link",
      desc: "One-click checkout with email + saved payment methods",
      api: "Stripe Link (Payment Element / Checkout with link enabled)",
      userInput: [
        "Email address (first time or returning)",
        "SMS one-time code for Link authentication (if required)",
        "Optional: save new card to Link vault"
      ],
      merchantProvides: [
        "Stripe account with Link enabled",
        "PaymentIntent or Checkout Session with customer email prefilled",
        "customer_creation / customer email in session",
        "Same webhooks as card; Link is a UX layer on Stripe PMs"
      ],
      integration: [
        "Enable Link in Payment Element or use Stripe Checkout",
        "User enters email → Link autofill or OTP → confirm PI",
        "Returning users skip card re-entry",
        "Fulfill on payment_intent.succeeded"
      ],
      international: [
        "Link availability follows Stripe country support; not all regions yet.",
        "Saved cards remain issuer-bound — cross-border charges still apply FX/fees.",
        "Good for repeat Career Lab purchases / upsells in supported countries.",
        "Privacy: Link is Stripe-hosted vault; disclose in privacy policy."
      ],
      docs: "https://docs.stripe.com/payments/link"
    },
    {
      id: "alipay",
      href: "/methods/alipay/",
      icon: "支",
      cls: "cn",
      title: "Alipay 支付宝",
      titleZh: "支付宝",
      desc: "QR / in-app — async notify; settlement delayed vs cards",
      api: "Alipay+ / Antom Create Payment Session — or Stripe alipay PM (region-limited)",
      userInput: [
        "Alipay app login + payment password / biometrics",
        "Scan merchant QR (Native) or confirm in-app (WAP/H5)",
        "Buyer sees amount in CNY or converted display per product rules"
      ],
      merchantProvides: [
        "Cross-border or domestic Alipay merchant onboarding (license, settlement account)",
        "out_trade_no (unique order id), total_amount, subject, product_code",
        "notify_url (async callback URL) + RSA/AES signature keys",
        "Return URL for browser flows; reconcile via notify not front-end return"
      ],
      integration: [
        "Backend: signed request to create prepay / payment session → QR code URL",
        "Frontend: display QR or redirect to Alipay cashier",
        "User pays in Alipay app",
        "Alipay POSTs notify_url → verify signature → mark order paid → respond success"
      ],
      international: [
        "Cross-border e-commerce requires Alipay global / Antom merchant program — separate KYC from US Stripe.",
        "Settlement often CNY → FX to USD bank; timing T+1 to several days; holiday calendars differ.",
        "Regulatory: real-name rules, transaction limits, prohibited categories for education vary by corridor.",
        "Always treat notify webhook as source of truth; user closing browser ≠ payment failed."
      ],
      docs: "https://docs.antom.com/"
    },
    {
      id: "wechat_pay",
      href: "/methods/wechat-pay/",
      icon: "微",
      cls: "cn",
      title: "WeChat Pay 微信支付",
      titleZh: "微信支付",
      desc: "Native QR / JSAPI / H5 — API v3 with platform certificates",
      api: "WeChat Pay API v3 (Native / JSAPI / H5)",
      userInput: [
        "WeChat app scan QR (Native) or in-wechat browser pay (JSAPI)",
        "Payment password / biometric in WeChat",
        "For JSAPI: must open inside WeChat with openid bound"
      ],
      merchantProvides: [
        "WeChat Pay merchant ID (mchid), appid (official account or mini program)",
        "API v3 key, merchant private key, platform certificate serial",
        "out_trade_no, amount { total, currency CNY }, description, notify_url",
        "For JSAPI: OAuth openid; for Native: code_url in response"
      ],
      integration: [
        "Backend: POST /v3/pay/transactions/native (or jsapi/h5)",
        "Frontend: show code_url QR or invoke WeChat JS bridge",
        "User pays → WeChat async notify (encrypted resource)",
        "Backend decrypt notify, idempotent update order, return 200 SUCCESS"
      ],
      international: [
        "Overseas merchants need cross-border WeChat Pay institution (e.g. HK/EU entity) — not plug-and-play with US LLC alone.",
        "Primarily CNY; FX and remittance to offshore account subject to SAFE/PCI policies.",
        "JSAPI requires Chinese WeChat ecosystem; Native QR works for diaspora scanning.",
        "Long holidays (CNY) delay settlement; plan pending UX like ACH."
      ],
      docs: "https://pay.weixin.qq.com/wiki/doc/apiv3/index.shtml"
    }
  ];

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function renderDetail(method, checkoutHref) {
    if (!method) {
      return (
        '<div class="method-detail-empty">' +
        "<p>Select a payment method to view API requirements, integration flow, and cross-border notes.</p>" +
        "<p class=\"method-detail-empty-zh\">选择一种支付方式，查看 API 所需信息、调用流程与国际支付说明。</p>" +
        "</div>"
      );
    }

    function listItems(items) {
      return (
        "<ul>" +
        items.map(function (item) {
          return "<li>" + escapeHtml(item) + "</li>";
        }).join("") +
        "</ul>"
      );
    }

    function numbered(items) {
      return (
        "<ol>" +
        items.map(function (item) {
          return "<li>" + escapeHtml(item) + "</li>";
        }).join("") +
        "</ol>"
      );
    }

    return (
      '<article class="method-detail" data-method-id="' +
      escapeHtml(method.id) +
      '">' +
      '<header class="method-detail-header">' +
      '<span class="method-icon method-icon--' +
      escapeHtml(method.cls) +
      '">' +
      escapeHtml(method.icon || "Pay") +
      "</span>" +
      "<div>" +
      "<h2>" +
      escapeHtml(method.title) +
      "</h2>" +
      '<p class="method-detail-sub">' +
      escapeHtml(method.titleZh) +
      " · " +
      escapeHtml(method.desc) +
      "</p>" +
      "</div>" +
      "</header>" +
      '<p class="method-detail-api"><strong>API</strong> ' +
      escapeHtml(method.api) +
      "</p>" +
      '<div class="method-detail-grid">' +
      '<section class="method-detail-block">' +
      "<h3>User input <span>用户需填写 / 授权</span></h3>" +
      listItems(method.userInput) +
      "</section>" +
      '<section class="method-detail-block">' +
      "<h3>We provide <span>商户 / 系统需提供</span></h3>" +
      listItems(method.merchantProvides) +
      "</section>" +
      '<section class="method-detail-block method-detail-block--wide">' +
      "<h3>How to integrate <span>调用流程</span></h3>" +
      numbered(method.integration) +
      "</section>" +
      '<section class="method-detail-block method-detail-block--wide method-detail-block--intl">' +
      "<h3>International &amp; cross-border <span>国际支付注意</span></h3>" +
      listItems(method.international) +
      "</section>" +
      "</div>" +
      (method.docs
        ? '<p class="method-detail-docs"><a href="' +
          escapeHtml(method.docs) +
          '" target="_blank" rel="noopener noreferrer">Official docs →</a></p>'
        : "") +
      (checkoutHref
        ? '<a class="btn-primary method-detail-cta" href="' +
          escapeHtml(checkoutHref) +
          '">Continue to checkout demo</a>'
        : "") +
      "</article>"
    );
  }

  global.HeerisePaymentMethodsInfo = {
    METHODS: METHODS,
    getById: function (id) {
      for (var i = 0; i < METHODS.length; i++) {
        if (METHODS[i].id === id) return METHODS[i];
      }
      return null;
    },
    renderDetail: renderDetail
  };
})(window);
